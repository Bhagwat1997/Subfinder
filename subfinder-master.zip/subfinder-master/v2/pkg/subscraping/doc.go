// Package subscraping contains the logic of scraping agents
package subscraping
